"use strict";





/*
var cancel = document.querySelector('.cancelar');
cancel.addEventListener("click", function(e){
	e.preventDefault();
	cancelar();
    console.log('testando botão cancelar')
});


function cancelar(){
	var cancel = confirm('Deseja mesmo cancelar?\nCaso sim, perderá todos os dados não salvos')
	
    if(cancel){
		location.href = 'home'; 
	}
	
}*/









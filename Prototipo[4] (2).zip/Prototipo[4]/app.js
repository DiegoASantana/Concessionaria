const express = require('express');
const app = express();
const port = 8081;
const handlebars = require('express-handlebars');
const bodyParser = require('body-parser');
const session = require('express-session')
const Veiculo = require('./models/Veiculo');
const db = require('./models/db');
const Funcionario = require('./models/Funcionario');





// Config
	// Template Engine
		app.engine('handlebars', handlebars.engine({defaultLayout: 'main'}));
		app.set('view engine', 'handlebars');


	//Body Parser
		app.use(bodyParser.urlencoded({extended: false}));
		app.use(bodyParser.json());
		app.use(express.static(__dirname + '/views'));
		app.use(express.static(__dirname + '/public'));
		app.use(session({secret:'asdkjnsdijuhsdfiouhsdfj'}));
		


		app.use('/estoque',require('./Routes/rota_estoque'));
		app.use('/index',require('./Routes/rota_user'));
		app.use('/clientes',require('./Routes/rota_cliente'));
		app.use('/funcionarios',require('./Routes/rota_funcionario'));
		app.use('/vendas',require('./Routes/rota_vendas'));
		



//Rotas

	
	app.get('/home', (req,res)=>{
		res.render('home')
	})
	

	app.get('/home2', (req,res)=>{
		res.render('home2');
	})

	app.get('/fornecedores', (req, res) =>{
		res.render('fornecedores');
	});


	app.get('/funcionarios', (req, res) =>{
		res.render('funcionarios');
	});


	

	
	

	
	

app.listen(port, function(){
	console.log("Projeto executando na porta: " + port);
});

module.exports = app;